<?php

class Ayoola_Interface
{
// My Validators implementing this must have the following methods

    public function validated( $value )
	
    public function errorMessages()
 
}
