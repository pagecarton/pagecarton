<?php

interface Ayoola_Doc_Adapter_Interface
{
    public function view(); 
}
