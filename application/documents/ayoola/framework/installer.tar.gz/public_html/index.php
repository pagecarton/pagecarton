<?php 

	//	Report all PHP errors
	error_reporting( E_ALL & ~E_STRICT & ~E_NOTICE & ~E_USER_NOTICE );
	ini_set( 'display_errors', "0" );	 
	ini_set( "memory_limit","512M" );	

//	exit( "testing 1, 2, 3." );
//	var_export( $_COOKIE );	echo "<br />\n";
//	isset( $_SESSION ) ? null : session_start();
//	echo "<br />\n"; foreach($_SERVER as $key=>$val) {echo  '$_SERVER['.$key."] = $val<br />\n";}	
//  Detect path to application
	//defined('APPLICATION_DIR') || define('APPLICATION_DIR', realpath(dirname(dirname(__FILE__))));
	$dir = realpath( dirname( dirname( @$_SERVER['SCRIPT_FILENAME'] ) ) ); 
//	$_COOKIE['SUB_DIRECTORY'] = 'ayoola';
//	var_export( $_COOKIE['SUB_DIRECTORY'] );
//	var_export( $dir );
	defined( 'APPLICATION_DIR' ) || define( 'APPLICATION_DIR', $dir );
	//defined('APPLICATION_DIR') || define('APPLICATION_DIR', realpath( $_SERVER['SCRIPT_FILENAME'] );
	
//   Include prerequisite    
	require_once 'Ayoola/Application.php';
	Ayoola_Application::run();
//	Ayoola_Application::log();
//	var_export(new Ayoola_Application( APPLICATION_ENV, BOOT_FILE ));	echo "<br />\n";
//	echo "<br />\n"; foreach($_SERVER as $key=>$val) {echo  '$_SERVER['.$key."] = $val<br />\n";}